## Дизайн DDI Editorial

- Перед работой прочитай `.interface-design/system.md`; используй относящиеся к задаче контракты в `design-system/README.md` и `design-system/components.json`.
- Значения цветов, шрифтов и размеров бери из `design-system/tokens.json`, готовые стили — из `design-system/ddi.css`.
- Сохраняй выбранные визуальные паттерны. В диалоге агента используются JSON-графика и мини-воронка, а не текстовый список вместо рисунков.
- Меняй исходники, затем запускай `node design-system/build.mjs` и `node design-system/build.mjs --check`; обновляй пример, контракт, версию и CHANGELOG.
- Эта система относится к standalone-документам; она не заменяет автоматически существующую компонентную библиотеку приложения.
