// Команды из финального gravity-standalone.html (Data-Driven Index).
import {productSurveyProfiles} from './survey-profiles.js';

const sourceTeams = [
  {
    "id": "339dfb56-42eb-5f1a-9440-3fd38e3ed81a¦БПИФ",
    "name": "БПИФ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "e982233c-5dff-599c-8b17-654d765327a1¦Брокерский счет",
    "name": "Брокерский счет",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "7fdb5658-795c-54e1-bc4a-0de761a9f33f¦Вклады+НС",
    "name": "Вклады+НС",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "2770002e-6b7e-5753-9915-189d0cf5272f¦Военная пенсия",
    "name": "Военная пенсия",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "e1b3b7f3-f7d1-5ce2-9089-0c1cc1e3a7f1¦ДСЖ КК",
    "name": "ДСЖ КК",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "7d3e85aa-cc1a-5831-9db0-35735fe9bd0a¦ДУ",
    "name": "ДУ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "4ef58f86-536f-5fdc-a364-671f3dc471d2¦Дебетовая карта",
    "name": "Дебетовая карта",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "bf64fa82-97b9-54e3-bdec-0992634e5181¦Детская карта",
    "name": "Детская карта",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "38f23c29-a890-550c-9189-14fbf103a873¦ЗПИФ",
    "name": "ЗПИФ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "5b9f9018-3e0e-5955-a174-bf90b2474b58¦Зарплатный продукт",
    "name": "Зарплатный продукт",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "a9785203-d57f-51c9-b1eb-16fbcc318e70¦ИСЖ",
    "name": "ИСЖ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "181a8be0-a6c1-5590-819c-b49ae1c80081¦ИнвестКопилка",
    "name": "ИнвестКопилка",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "7043f2b6-9836-55c4-8801-c9bde60b990d¦Интернет-Эквайринг",
    "name": "Интернет-Эквайринг",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "501ebceb-0d83-5f78-92bd-5e3507d11097¦Конверсия",
    "name": "Конверсия",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "1d15a169-21f9-501d-a44f-af2eb7bb3242¦Много денег (НКПЗН)",
    "name": "Много денег (НКПЗН)",
    "unit": "ДомКлик",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "ac8caf4d-ee9f-5df6-9eea-957009a39b68¦Монеты",
    "name": "Монеты",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "465539ee-d9a6-58d7-9027-80b06384db93¦НСЖ",
    "name": "НСЖ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "483b5e1a-6790-5f2e-944d-19e55b6a04ac¦ОПИФ",
    "name": "ОПИФ",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "a482e4ff-52f6-5868-812c-5a7f34a7eb0b¦Объект Авто",
    "name": "Объект Авто",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "509442c8-9195-560e-8ae8-62357bfcfc5b¦ПДС",
    "name": "ПДС",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "d16442dc-cde3-5400-b123-69dc5df2dce1¦Пакет услуг СберПервый",
    "name": "Пакет услуг СберПервый",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "cf93b82b-89a1-588c-992b-ed349f585aa0¦Пакет услуг СберПремьер",
    "name": "Пакет услуг СберПремьер",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "4ecce79e-254e-51cf-b125-e5e5221cc0ed¦Пенсионный продукт",
    "name": "Пенсионный продукт",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "4bf2be31-ba6b-5ee2-b60d-bf62932ea0ce¦Переводы по РФ",
    "name": "Переводы по РФ",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "20f8336c-e0cf-5944-9c0e-5f201a9c4561¦Переводы подарков",
    "name": "Переводы подарков",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "aa80593f-3f07-5935-96b3-2e367d6a78f4¦Платежи",
    "name": "Платежи",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "5b3c81af-8ad4-5fcd-84c0-729f3f44093f¦СберЧаевые",
    "name": "СберЧаевые",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "da0844f0-ff56-519d-97cb-a72ec1d97225¦Сделка ИЖС",
    "name": "Сделка ИЖС",
    "unit": "ДомКлик",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "59417ede-ab71-55f8-a4b0-d3928f8a6647¦Сделка вторичка",
    "name": "Сделка вторичка",
    "unit": "ДомКлик",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "4e6167da-2232-56cf-9afb-ddde94d2f568¦Сделка с Первичным жильём",
    "name": "Сделка с Первичным жильём",
    "unit": "ДомКлик",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "a49f65b1-286e-592a-974a-49b980740328¦Сейфы",
    "name": "Сейфы",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "5eab8ed3-2334-5e08-9c7f-6c241d78e7a0¦Страхование залога",
    "name": "Страхование залога",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "9ab3c21c-493a-54dc-92ec-022aefb84f84¦Сценарии оплаты",
    "name": "Сценарии оплаты",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "719150cf-b54c-5fc1-93f1-42b185e30be4¦Торговый Эквайринг",
    "name": "Торговый Эквайринг",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "9721f391-d1a5-57d5-beb1-e0eaccbf0ed1¦Трансграничные переводы",
    "name": "Трансграничные переводы",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "75028b72-7f89-55c1-a309-8c5b4193250a¦Трансграничный эквайринг",
    "name": "Трансграничный эквайринг",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "b4d7d4f8-e4c7-5cc2-ada8-9fb3801fb28a¦Транспортный эквайринг",
    "name": "Транспортный эквайринг",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "febe33a0-05c9-50d9-989c-9c1067e3ab21¦ЦФА",
    "name": "ЦФА",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "8e9b9731-8712-59fd-b654-6aac03844b1c¦Школьные сервисы",
    "name": "Школьные сервисы",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "3efab4a2-1a23-5f08-9b67-a56b5056d320¦SberPay Ecom",
    "name": "SberPay Ecom",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "a7c319ef-d22f-58f7-96ca-8877155e4d37¦SberPay Вжух",
    "name": "SberPay Вжух",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "4e10cf58-0146-5b04-b7c4-c5fa1651edef¦Автокредит",
    "name": "Автокредит",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "8cba2f54-2829-5599-9ee7-d1f288bb1f03¦ВЗР",
    "name": "ВЗР",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "ad4bf2f6-8fc5-5c61-8ea1-11c2a002d46f¦Выписки, справки",
    "name": "Выписки, справки",
    "unit": "PC",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "e8c97fe4-bd38-5aa1-9388-5c532cbde6f2¦ДСЖ ПК",
    "name": "ДСЖ ПК",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "bb7deb0e-9cae-571b-8c6a-8ba70df1eac0¦ЗЛС",
    "name": "ЗЛС",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "8d8237a3-4012-5931-a9b4-de6dd6fb934a¦Залоговое страхование (корпоративное страхование)",
    "name": "Залоговое страхование (корпоративное страхование)",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "e146d7b5-0627-5493-b841-3e87393d585c¦Как зарплатный",
    "name": "Как зарплатный",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "afe119a5-a944-5e11-90f9-e3facbd32e5c¦Кредитные карты",
    "name": "Кредитные карты",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "8ad8f20e-b44c-5259-82a7-497fc20b63e0¦ОМС",
    "name": "ОМС",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "5bf90a68-dd2e-5c7f-bd23-d0c725521c61¦СберСова",
    "name": "СберСова",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "e3eb17b1-d33d-512e-8858-78626a7bc85a¦Слитки",
    "name": "Слитки",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "72c0ced8-4d7d-50e4-845d-8f5d29331ba7¦Страхование жизни",
    "name": "Страхование жизни",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "73700110-c3a4-579b-99dd-5e060dace400¦Кредитный потенциал",
    "name": "Кредитный потенциал",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "dc05bd52-1a59-57a4-b5ea-3fad5586eac9¦Образовательный кредит",
    "name": "Образовательный кредит",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "89b13e92-db89-516e-823f-1d102242bdc9¦КАСКО",
    "name": "КАСКО",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "16a909e6-2a89-532d-b1df-1f749aff70c8¦ОСАГО",
    "name": "ОСАГО",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "723125c3-303d-5d2e-adc3-18460f242f63¦СберПрайм",
    "name": "СберПрайм",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "a9b4baac-cf13-5c97-babd-4c1b4fd3b831¦POS-кредиты",
    "name": "POS-кредиты",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "715a3090-94df-5954-b638-bb36c1ae24ae¦Личная защита Плюс",
    "name": "Личная защита Плюс",
    "unit": "УБ",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "12e8afe0-485e-5aa1-9827-45fad098a603¦SberPay NFC",
    "name": "SberPay NFC",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "11a243e6-5b73-56ad-8ac7-203e0d744062¦Оплата улыбкой",
    "name": "Оплата улыбкой",
    "unit": "DB",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "3db3e72b-6602-5c2d-8b17-d7d7d6c26acd¦Потребительский кредит",
    "name": "Потребительский кредит",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "aee72194-01f2-5673-9c7b-ed2beff1432a¦СберСпасибо",
    "name": "СберСпасибо",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": 1
    }
  },
  {
    "id": "46ef0414-acac-5f20-99a8-31069cc42ccb¦BNPL",
    "name": "BNPL",
    "unit": "CBP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "a9bdb854-e0d5-5cb3-8aa0-746826d70992¦Дети",
    "name": "Дети",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 0,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "bd37f32f-c457-542d-b2d0-ba170c3d1fca¦Зрелость",
    "name": "Зрелость",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 0.25,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "83d2bd82-e67b-5432-9c81-604090f9d311¦Колл-центр",
    "name": "Колл-центр",
    "unit": "PC",
    "mechanicScores": {
      "Удержание клиентов": null,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "0b1990e4-3fd5-5f25-8f50-110ffedac76f¦МВС",
    "name": "МВС",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1.25,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "b89fb857-45f0-5046-9811-cfcb31c0a656¦Молодежь",
    "name": "Молодежь",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1.5,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "194a82fd-fe84-5d51-ad16-91b4e67eae64¦СберKids",
    "name": "СберKids",
    "unit": "DP",
    "mechanicScores": {
      "Удержание клиентов": 0.25,
      "Возврат клиентов": 0.25,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "d63b6b2a-2c61-538e-b59f-7e18650adfc1¦Телемаркетинг",
    "name": "Телемаркетинг",
    "unit": "PC",
    "mechanicScores": {
      "Удержание клиентов": null,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "16b48c34-9b69-5403-8da8-41943903e5ff¦Чат",
    "name": "Чат",
    "unit": "PC",
    "mechanicScores": {
      "Удержание клиентов": null,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "080dbf15-22d2-5498-9965-a68765826ebf¦СБОЛ",
    "name": "СБОЛ",
    "unit": "DP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "88128c62-fad4-53de-b101-1851df4d4d14¦СберИнвестор",
    "name": "СберИнвестор",
    "unit": "DP",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 0.5,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "02489dde-00ff-516f-b162-20865c9a7106¦Уведомления",
    "name": "Уведомления",
    "unit": "DP",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "cbb36731-ec7c-5e0c-9516-c3b21328e952¦Рабочий возраст",
    "name": "Рабочий возраст",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1.5,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "371e8205-137b-5e04-9212-c2c9c57e0d04¦PB",
    "name": "PB",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1.25,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "74567319-718b-554b-a770-096b8acbecdf¦Top Affluent",
    "name": "Top Affluent",
    "unit": "CX",
    "mechanicScores": {
      "Удержание клиентов": 1.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "f0050a4f-3ce4-5c90-b5f5-627256453071¦SberID",
    "name": "SberID",
    "unit": "Data",
    "mechanicScores": {
      "Удержание клиентов": null,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "4a1bd6b8-c295-50fd-b4c6-14d4873c6bb0¦Единый личный кабинет (ЕЛК)",
    "name": "Единый личный кабинет (ЕЛК)",
    "unit": "Data",
    "mechanicScores": {
      "Удержание клиентов": 0.5,
      "Возврат клиентов": 0,
      "Допродажи (upsell)": null
    }
  },
  {
    "id": "2aed0e7e-8d0a-5554-8d8e-7716e998cdea¦Почта, Диск, Календарь",
    "name": "Почта, Диск, Календарь",
    "unit": "Data",
    "mechanicScores": {
      "Удержание клиентов": 1,
      "Возврат клиентов": 1,
      "Допродажи (upsell)": 0
    }
  },
  {
    "id": "6d607e87-5e45-5759-a9cc-1a162b981a26¦Персональная рекомендация",
    "name": "Персональная рекомендация",
    "unit": "Data",
    "mechanicScores": {
      "Удержание клиентов": null,
      "Возврат клиентов": null,
      "Допродажи (upsell)": null
    }
  }
];

// Та же сортировка, что compareNames в DDI Catalog.jsx.
const nameCollator = new Intl.Collator('en', {sensitivity: 'base', numeric: true});

const translit = {
  а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'yo', ж: 'zh', з: 'z',
  и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r',
  с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'shch',
  ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya',
};
const compactSearch = value => String(value).toLocaleLowerCase('ru-RU').replaceAll('ё', 'е').replace(/[^a-zа-я0-9]/g, '');
const romanize = (value, simple = false) => [...String(value).toLocaleLowerCase('ru-RU')]
  .map(char => simple ? ({ё: 'e', х: 'h', ц: 'c', щ: 'sch'}[char] ?? translit[char] ?? char) : (translit[char] ?? char))
  .join('').replace(/[^a-z0-9]/g, '');

export function filterTeamOption(option, filter) {
  const query = compactSearch(filter);
  if (!query) return true;
  const name = option.text || option.content || option.value || '';
  return [compactSearch(name), romanize(name), romanize(name, true)]
    .some(candidate => candidate.includes(query));
}

// Актуальный состав DB: только согласованный перечень и отдельные B2C/B2B.
export const dailyBankingNames = [
  'Зарплатный продукт', 'Пенсионный продукт', 'SberPay NFC', 'Переводы по РФ',
  'Оплата улыбкой', 'Торговый Эквайринг', 'Кредитные карты', 'Дебетовая карта',
  'SberPay Ecom', 'Платежи', 'Вжух', 'Детская карта', 'Интернет-Эквайринг',
];
export const teams = [
  ...sourceTeams.filter(team => productSurveyProfiles[team.id] && (team.unit !== 'DB'
    || dailyBankingNames.includes(team.name === 'SberPay Вжух' ? 'Вжух' : team.name)))
    .map(team => team.name === 'SberPay Вжух' ? {...team, name: 'Вжух'} : team),
  ...Object.values(productSurveyProfiles).filter(profile => profile.fullSurvey).map(profile => ({
    id: profile.teamId, name: profile.name, unit: 'DB', mechanicScores: {},
  })),
];

export const enabledTeam = teams.find(team => team.name === 'Вклады+НС');
export const CHANNEL_SURVEYS_ENABLED = false;
export const enabledTeams = teams.filter(team => Boolean(productSurveyProfiles[team.id]));
const enabledTeamIds = new Set(enabledTeams.map(team => team.id));
export const teamGroups = [...new Set(teams.map(team => team.unit))]
  .map(unit => ({
    label: unit,
    options: teams.filter(team => team.unit === unit)
      .sort((a, b) => nameCollator.compare(a.name, b.name))
      .map(team => ({value: team.id, content: team.name, text: team.name, disabled: !enabledTeamIds.has(team.id)})),
  }))
  .sort((a, b) => nameCollator.compare(a.label, b.label));
