import {quarterlyAnalysisCodes, correctTypos, allowsMissingMetric, isOptionSelected, hasAnswer, inlineQuestions, knownMechanics, showsOptionalComment, needsComment, needsEvidence, needsProof, needsReason, getSections, visibleQuestions, evidenceResponse} from './questions.js';
import {teams, CHANNEL_SURVEYS_ENABLED} from './teams.js';
import {scoringBaseline} from './scoring-baseline.js';
import {callCenterBaseline, callCenterScoreRules} from './call-center.js';
import {productSurveyProfiles} from './survey-profiles.js';
import {metricSourceEvidence, metricSourceFields} from './metric-source.js';

const round = value => Math.round(value * 10000) / 10000;
const text = value => String(value ?? '').trim();
const selected = value => Array.isArray(value) ? value : value ? [value] : [];

export function buildSurveyResult(answers, backlogAnalyzed = false, completedAt = new Date().toISOString()) {
  const team = teams.find(item => item.id === answers.product);
  const isCallCenter = CHANNEL_SURVEYS_ENABLED && team?.id === callCenterBaseline.teamId;
  const productProfile = productSurveyProfiles[team?.id];
  const isOtherProduct = Boolean(productProfile && team.id !== scoringBaseline.teamId);
  const baseline = isCallCenter ? callCenterBaseline : productProfile || scoringBaseline;
  if (!team || team.id !== baseline.teamId) throw new Error('Unsupported survey team');
  const catalogue = getSections(answers);
  answers = {...answers};
  for (const q of catalogue.flatMap(s => s.questions).flatMap(q => [q, ...inlineQuestions(q)])) {
    if (q.type === 'multi' && Array.isArray(answers[q.id])) answers[q.id] = answers[q.id].map(correctTypos);
    if (q.type === 'radio' && typeof answers[q.id] === 'string') answers[q.id] = correctTypos(answers[q.id]);
  }
  for (const q of catalogue.flatMap(section => section.questions)) {
    if (q.action) answers[q.action.id] = isOptionSelected(q, answers, q.actionOption) ? 'Да' : 'Нет';
    if (q.benchmark) answers[q.benchmark.id] = q.benchmarkOnly ? answers[q.id] : isOptionSelected(q, answers, 'Бенчмарки') ? 'Да' : 'Нет';
  }
  const questions = catalogue.flatMap(section => visibleQuestions(section, backlogAnalyzed, answers)).flatMap(q => [q, ...inlineQuestions(q, answers), ...(q.benchmark ? [q.benchmark] : []), ...(q.action ? [q.action] : [])]).filter(q => q.type !== 'info');
  if (questions.some(q => !hasAnswer(q, answers))) throw new Error('Incomplete survey');
  // Export only the current branch; old hidden proofs/comments are excluded.
  const cleanAnswers = {};
  const questionRows = {};
  for (const q of questions) {
    cleanAnswers[q.id] = Array.isArray(answers[q.id]) ? answers[q.id].filter(option => q.options.includes(option)) : answers[q.id];
    if (q.type === 'links') {
      const format = answers[`${q.id}Unknown`] === true ? 'unknown' : answers[`${q.id}Format`] || 'link';
      cleanAnswers[`${q.id}Format`] = format;
      cleanAnswers[q.id] = format === 'unknown' ? 'Затрудняюсь ответить' : format === 'excel' ? 'Отчетность в формате Excel' : String(answers[q.id] ?? '');
      questionRows[`${q.id}Format`] = q.row;
    }
    if (allowsMissingMetric(q, answers)) {
      cleanAnswers[q.id] = null;
      cleanAnswers[`${q.id}Unknown`] = true;
      questionRows[`${q.id}Unknown`] = q.row;
    }
    if (q.previousOptions?.length) cleanAnswers[q.id] = [...new Set([...q.previousOptions, ...selected(cleanAnswers[q.id])])];
    questionRows[q.id] = q.row;
    if (showsOptionalComment(q, answers) && text(answers[q.optionalCommentId])) {
      cleanAnswers[q.optionalCommentId] = String(answers[q.optionalCommentId]);
      questionRows[q.optionalCommentId] = q.row;
    }
    if (selected(answers[q.id]).some(option => /Свой вариант|Что-то ещ[её]|^Другое$/.test(option))) {cleanAnswers[`${q.id}Other`] = answers[`${q.id}Other`]; questionRows[`${q.id}Other`] = q.row;}
    if (needsComment(q, answers)) {cleanAnswers[q.commentId] = answers[q.commentId]; questionRows[q.commentId] = q.row;}
    if (needsReason(q, answers) && (!q.reasonOptional || text(answers[q.reasonId]))) {
      cleanAnswers[q.reasonId] = String(answers[q.reasonId]);
      questionRows[q.reasonId] = q.row;
    }
    if (needsProof(q, answers)) {
      const fields = q.inlineProof.kind === 'metricSource' ? metricSourceFields(q.inlineProof, answers)
        : {[q.inlineProof.id]: answers[q.inlineProof.id]};
      Object.assign(cleanAnswers, fields);
      for (const id of Object.keys(fields)) questionRows[id] = q.inlineProof.row;
    }
  }
  const activeInlineQuestions = questions.filter(q => needsEvidence(q, answers));
  const evidenceById = new Map(activeInlineQuestions.map(q => [q.inlineEvidence.id, q.inlineEvidence]));
  for (const activeInlineEvidence of evidenceById.values()) {
    const {id, formatId, row} = activeInlineEvidence;
    const response = evidenceResponse(activeInlineEvidence, answers);
    cleanAnswers[formatId] = response.format;
    if (response.format === 'unknown') cleanAnswers[id] = 'Затрудняюсь ответить';
    else if (!['excel', 'unavailable'].includes(response.format)) cleanAnswers[id] = response.value;
    if (response.format === 'unavailable' && response.comment) {
      cleanAnswers[`${id}Comment`] = response.comment;
      questionRows[`${id}Comment`] = row;
    }
    if (response.correction) {
      cleanAnswers[`${id}Correction`] = response.correction;
      questionRows[`${id}Correction`] = row;
    }
    questionRows[id] = row;
    questionRows[formatId] = row;
  }
  const questionSources = Object.fromEntries(questions.map(q => [q.id, q.id === 'product'
    ? {source: 'ddi_team_catalog', sheet: null, row: null}
    : {sheet: q.sheet || (isCallCenter ? 'Каналы Phigital' : 'Продукты (2)'), row: q.row,
      ...(q.adaptedFrom ? {adaptedFrom: q.adaptedFrom, accuracyReview: true} : {})}]));
  for (const q of questions) {
    if (q.type === 'links') questionSources[`${q.id}Format`] = {sheet: q.sheet || 'Продукты (2)', row: q.row};
    if (allowsMissingMetric(q, answers)) questionSources[`${q.id}Unknown`] = {sheet: q.sheet || 'Продукты (2)', row: q.row};
    if (q.optionalCommentId && cleanAnswers[q.optionalCommentId]) questionSources[q.optionalCommentId] = {sheet: q.sheet || 'Продукты (2)', row: q.row};
    if (needsReason(q, answers) && (!q.reasonOptional || text(answers[q.reasonId]))) questionSources[q.reasonId] = {
      sheet: q.sheet || 'Продукты (2)', row: q.row,
    };
  }
  for (const activeInlineQuestion of activeInlineQuestions) {
    const activeInlineEvidence = activeInlineQuestion.inlineEvidence;
    const source = {sheet: activeInlineQuestion.sheet || 'Продукты (2)', row: activeInlineEvidence.row,
      ...(activeInlineEvidence.previousSource ? {previousSource: activeInlineEvidence.previousSource} : {})};
    questionSources[activeInlineEvidence.id] = source;
    questionSources[activeInlineEvidence.formatId] = source;
    if (cleanAnswers[`${activeInlineEvidence.id}Comment`]) questionSources[`${activeInlineEvidence.id}Comment`] = source;
    if (activeInlineEvidence.previousLinks) questionSources[`${activeInlineEvidence.id}Correction`] = source;
  }

  for (const q of questions) {
    if (needsProof(q, answers)) {
      const fields = q.inlineProof.kind === 'metricSource' ? metricSourceFields(q.inlineProof, answers) : {[q.inlineProof.id]: answers[q.inlineProof.id]};
      for (const id of Object.keys(fields)) questionSources[id] = {sheet: q.sheet || 'Продукты (2)', row: q.inlineProof.row};
    }
  }

  for (const id of Object.keys(cleanAnswers)) {
    if (!questionSources[id]) questionSources[id] = {sheet: isCallCenter ? 'Каналы Phigital' : 'Продукты (2)', row: questionRows[id] ?? null};
  }

  const updates = new Map();
  const metricSourceEvidenceById = new Map(questions.filter(q => q.inlineProof?.kind === 'metricSource')
    .map(q => [q.inlineProof.id, metricSourceEvidence(q.inlineProof, answers)]));
  function score(code, questionId, fraction, rule, evidenceId) {
    const metric = baseline.metrics.find(item => item.code === code);
    if (!metric || !questions.some(q => q.id === questionId)) return;
    if (isOtherProduct && !code.startsWith('general.') && !quarterlyAnalysisCodes.includes(code) && code !== 'hyp.discovery_40_backlog'
      && Number(metric.value) >= Number(metric.max_value)) return;
    const inlineEvidence = evidenceById.get(evidenceId);
    updates.set(code, {
      questionId,
      value: round(metric.max_value * Math.max(0, Math.min(1, fraction))),
      rule,
      evidence: evidenceId ? metricSourceEvidenceById.get(evidenceId) || cleanAnswers[evidenceId] ||
        (inlineEvidence && cleanAnswers[inlineEvidence.formatId] === 'excel'
          ? 'Отчет в формате Excel' : null) : null,
      requiresReview: true,
    });
  }

  const knowledge = {
    marketRussia: 'general.obъem_celevogo_rynka_v_rossii',
    marketSber: 'general.obъem_celevogo_rynka_v_sbere',
    clients: 'general.klienty_s_produktom',
    mau: 'general.mau_produkta',
    dau: 'general.dau_produkta',
    yau: 'general.yau_produkta',
    dauMau: 'general.dau_mau',
    satellite: 'general.znanie_produktov_sputnikov',
  };
  for (const [id, code] of Object.entries(knowledge)) score(code, id, text(answers[id]) ? 1 : 0, 'answer_present; accuracy_requires_review', id === 'satellite' ? undefined : `${id}Source`);
  const monitor = selected(answers.monitoring);
  const full = monitor.includes('Дашборд в Навигаторе (доступны все метрики)');
  const partial = monitor.includes('Дашборд в Навигаторе (доступна часть метрик)');
  score('general.navigator_reporting_knowledge', 'monitoring', full ? 1 : partial ? 0.5 : 0, 'navigator_all=1; navigator_partial=0.5; other=0');

  // Versioned self-report rubric. These estimates are not a verified DDI update.
  for (const [prefix, includesId, analysisId, proofId] of [
    ['attract', 'attractIncludes', 'attractAnalysis', 'attractReport'],
    ['churn', 'churnIncludes', 'churnAnalysis', 'churnReport'],
  ]) {
    const includesQ = questions.find(q => q.id === includesId);
    const analysisQ = questions.find(q => q.id === analysisId);
    if (includesQ && !includesQ.benchmarkOnly) {
      const positive = includesQ.options.filter(option => !['Затрудняюсь ответить', 'Бенчмарки'].includes(option));
      const choices = [...(includesQ.previousOptions || []), ...selected(answers[includesId])];
      const count = positive.filter(option => choices.includes(option)).length;
      score(`${prefix}.report_completeness`, includesId, count / positive.length, 'selected_positive_elements / available_positive_elements', proofId);
    }
    if (analysisQ && !analysisQ.actionOnly) {
      const positive = analysisQ.options.filter(option => !['Все перечисленное выше', 'Не проводился', 'Затрудняюсь ответить', analysisQ.actionOption].includes(option));
      const choices = selected(answers[analysisId]);
      const fraction = choices.includes('Все перечисленное выше') ? 1 : positive.filter(option => choices.includes(option)).length / positive.length;
      score(`${prefix}.funnel_analysis`, analysisId, fraction, 'all=1; otherwise selected_analysis_dimensions / available_dimensions', proofId);
    }
  }
  score('attract.benchmarks', 'benchmarksAttract', answers.benchmarksAttract === 'Да' ? 1 : 0, 'yes=1; other=0', 'benchmarkAttractProof');
  score('churn.benchmarks', 'benchmarksChurn', answers.benchmarksChurn === 'Да' ? 1 : 0, 'yes=1; other=0', 'benchmarkChurnProof');
  score('churn.deviation_actions', 'deviations', answers.deviations === 'Да' ? 1 : 0, 'yes=1; other=0', 'deviationExampleReport');
  score('attract.initiatives_list', 'attractDeviations', answers.attractDeviations === 'Да' ? 1 : 0, 'yes=1; other=0', 'attractDeviationExampleReport');
  score('attract.nastroena_otchetnostь', 'attractConfigured', answers.attractConfigured === 'Да, автоматическая (monthly/weekly)' ? 1 : answers.attractConfigured === 'Да, по запросу' ? 0.5 : 0, 'automatic=1; on_request=0.5; other=0', 'attractReport');
  score('churn.nastroena_otchetnostь', 'churnConfigured', answers.churnConfigured === 'Да, автоматическая (monthly/weekly)' ? 1 : answers.churnConfigured === 'Да, по запросу' ? 0.5 : 0, 'automatic=1; on_request=0.5; other=0', 'churnReport');
  score('alerts.business_metrics', 'alerts', answers.alerts === 'Да' ? 1 : answers.alerts === 'Частично' ? 0.5 : 0, 'yes=1; partial=0.5; other=0');
  score('alerts.system_failures', 'systemAlerts', answers.systemAlerts === 'Да' ? 1 : answers.systemAlerts === 'Частично' ? 0.5 : 0, 'yes=1; partial=0.5; other=0');
  score('alerts.opovescheniya_po_problemam_svyazannym_s_ux_ui', 'uxAlerts', answers.uxAlerts === 'Да' ? 1 : answers.uxAlerts === 'Частично' ? 0.5 : 0, 'yes=1; partial=0.5; other=0');
  score('hyp.discovery_40_backlog', 'discovery', ['Больше 80%', 'От 40 до 79%'].includes(answers.discovery) ? 1 : 0, 'reported_discovery_at_least_40_percent=1; other=0', 'backlog');

  if (isOtherProduct && questions.some(q => q.id === 'usageIncludes' && !q.benchmarkOnly)) {
    const includes = questions.find(q => q.id === 'usageIncludes');
    const positive = includes.options.filter(option => !['Затрудняюсь ответить', 'Бенчмарки'].includes(option));
    const fraction = positive.filter(option => selected(answers.usageIncludes).includes(option)).length / positive.length;
    const code = baseline.metrics.some(metric => metric.code === 'voronka_ispolьzovaniya.polnota_otcheta')
      ? 'voronka_ispolьzovaniya.polnota_otcheta' : 'attract.report_completeness';
    score(code, 'usageIncludes', fraction, 'selected_positive_elements / available_positive_elements; accuracy_requires_review', 'usageReport');
  }
  if (isOtherProduct && questions.some(q => q.id === 'usageAnalysis' && !q.actionOnly)) {
    const analysis = questions.find(q => q.id === 'usageAnalysis');
    const positive = analysis.options.filter(option => !['Все перечисленное выше', 'Не проводился', 'Затрудняюсь ответить', analysis.actionOption].includes(option));
    const fraction = selected(answers.usageAnalysis).includes('Все перечисленное выше') ? 1 :
      positive.filter(option => selected(answers.usageAnalysis).includes(option)).length / positive.length;
    score('attract.provedenie_kompleksnogo_analiza_voronki_ispolьzovaniya', 'usageAnalysis', fraction,
      'selected_analysis_dimensions / available_dimensions; accuracy_requires_review', 'usageReport');
  }
  score('attract.nastroena_otchetnostь', 'usageConfigured', answers.usageConfigured === 'Да, автоматическая (monthly/weekly)' ? 1 : answers.usageConfigured === 'Да, по запросу' ? 0.5 : 0,
    'automatic=1; on_request=0.5; other=0; accuracy_requires_review', 'usageReport');

  const mechanicsQ = questions.find(q => q.id === 'upsell');
  const known = mechanicsQ ? knownMechanics(mechanicsQ, answers) : [];
  const mechanicCodes = {
    'Удержание клиентов': 'mehaniki.uderzhanie_klientov',
    'Возврат клиентов': 'mehaniki.vozvrat_klientov',
    'Допродажи (upsell)': 'mehaniki.doprodazhi_up_sell',
  };
  for (const [option, code] of Object.entries(mechanicCodes)) {
    if (!known.includes(option)) score(code, 'upsell', selected(answers.upsell).includes(option) ? 1 : 0, 'newly_selected_mechanic=1; other=0; previously_confirmed_preserved', 'mechanics');
  }

  if (isCallCenter) {
    for (const {code, questionId, kind, evidenceId, option} of callCenterScoreRules) {
      const q = questions.find(question => question.id === questionId);
      if (!q) continue;
      const answer = answers[questionId];
      let fraction = 0;
      if (kind === 'presence') fraction = text(answer) ? 1 : 0;
      else if (kind === 'optionSelected') fraction = selected(answer).includes(option) ? 1 : 0;
      else if (kind === 'yes') fraction = answer === 'Да' ? 1 : 0;
      else if (kind === 'partial') fraction = answer === 'Да' ? 1 : answer === 'Частично' ? 0.5 : 0;
      else if (kind === 'navigator') fraction = selected(answer).includes('Дашборд в Навигаторе (доступны все метрики)') ? 1 : selected(answer).includes('Дашборд в Навигаторе (доступна часть метрик)') ? 0.5 : 0;
      else if (kind === 'multiFraction') {
        const options = q.options.filter(option => !['Затрудняюсь ответить', 'Нет', 'Не проводился', 'Все перечисленное выше'].includes(option) && !/Свой вариант|Что-то ещ[её]|^Другое$/.test(option));
        fraction = selected(answer).includes('Все перечисленное выше') ? 1 : options.filter(option => selected(answer).includes(option)).length / options.length;
      } else if (kind === 'discovery') fraction = ['Больше 80%', 'От 40 до 79%'].includes(answer) ? 1 : 0;
      score(code, questionId, fraction, `call_center_${kind}; accuracy_requires_review`, evidenceId);
    }
  }

  const metrics = baseline.metrics.map(metric => {
    const update = updates.get(metric.code);
    return {
      code: metric.code,
      name: metric.name,
      baselineValue: metric.value,
      value: update ? update.value : metric.value,
      maxValue: metric.max_value,
      includedInIndex: metric.is_applicabble_flg !== false && !metric.excluded_from_index && Number(metric.dd_calculation_flg) !== 0 && Number(metric.max_value) > 0,
      source: update ? 'survey_self_report' : baseline.fullSurvey ? 'no_previous_answer' : 'ddi_baseline',
      rule: baseline.fullSurvey ? 'no_previous_answer' : 'ddi_baseline_preserved',
      ...(update || {}),
    };
  });
  const included = metrics.filter(metric => metric.includedInIndex);
  const points = round(included.reduce((sum, metric) => sum + Number(metric.value || 0), 0));
  const maxPoints = round(included.reduce((sum, metric) => sum + Number(metric.maxValue || 0), 0));
  const baselinePoints = round(included.reduce((sum, metric) => sum + Number(metric.baselineValue || 0), 0));
  return {
    schemaVersion: 1,
    surveyId: isCallCenter ? 'ddi-call-center' : isOtherProduct ? `ddi-product-${team.id.split('¦')[0]}` : 'ddi-deposits-ns',
    completedAt,
    team: {id: team.id, name: team.name, unit: team.unit},
    respondent: {name: cleanAnswers.name},
    answers: cleanAnswers,
    questionRows,
    questionSources,
    previousMechanics: [...new Set(questions.flatMap(q => knownMechanics(q, answers)))],
    previousFunnelElements: Object.fromEntries(questions.filter(q => q.previousOptions?.length).map(q => [q.id, q.previousOptions])),
    previousFunnelReports: Object.fromEntries(questions.filter(q => q.previousClickstreamUrl).map(q => [q.id, q.previousClickstreamUrl])),
    result: {
      status: 'provisional_self_report',
      ...(baseline.fullSurvey ? {fullSurvey: true, historicalBaselineAvailable: false, scoringWeightsRequireReview: true} : {}),
      scoringVersion: 'ddi-survey-self-report-v1',
      requiresBackendReview: true,
      baselinePeriod: baseline.period,
      baselinePoints: baseline.fullSurvey ? null : baselinePoints,
      points,
      maxPoints,
      scorePct: maxPoints ? round(points / maxPoints * 100) : null,
      baselineScorePct: !baseline.fullSurvey && maxPoints ? round(baselinePoints / maxPoints * 100) : null,
      scoredMetricCount: updates.size,
      unscoredGapMetricCodes: isOtherProduct ? baseline.metrics.filter(metric =>
        metric.is_applicabble_flg !== false && !metric.excluded_from_index && Number(metric.dd_calculation_flg) !== 0 &&
        Number(metric.value) < Number(metric.max_value) && !updates.has(metric.code)).map(metric => metric.code) : [],
      metrics,
    },
  };
}
